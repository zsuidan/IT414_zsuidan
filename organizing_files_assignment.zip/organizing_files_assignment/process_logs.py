from functions.filesystem_functions import *

processLogs()